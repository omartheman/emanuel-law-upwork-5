=== Monolit ===
* Contributors: CTHthemes
* Tags: custom-background, custom-menu, editor-style, featured-images, post-formats, sticky-post, theme-options, translation-ready
* Requires at least: 4.4
* Tested up to: 4.5.1
* Stable tag: 4.4.2
* License: GNU General Public License version 3.0
* License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==
* Monolit – Creative Responsive Architecture Wordpress Theme is perfect if you like a clean and modern design. This theme is ideal for architects, furniture designers, photographers, and those who need an easy, attractive and effective way to share their work with clients.
*   
*   
* Responsive Layout
* Custom Colors
* Custom Header
* Social Links
* Menu Description
* Post Formats
* The GNU General Public License version 3.0

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's ZIP (monolit.zip) file. Click Install Now.
3. Click Activate to use your new theme right away.

<?php
/* banner-php */

	if(is_active_sidebar('sidebar-3')){
        dynamic_sidebar('sidebar-3');
    }
    
?>
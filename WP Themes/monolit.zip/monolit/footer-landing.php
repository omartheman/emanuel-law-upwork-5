<?php
/* banner-php */
?> 
        </div>
        <!-- Main end -->
        <?php wp_footer(); ?>
        
    </body>
</html>